﻿namespace calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.buttonMul = new System.Windows.Forms.Button();
            this.buttonDel = new System.Windows.Forms.Button();
            this.buttonRes = new System.Windows.Forms.Button();
            this.buttonDiv = new System.Windows.Forms.Button();
            this.buttonMinus = new System.Windows.Forms.Button();
            this.buttonMin = new System.Windows.Forms.Button();
            this.buttonComa = new System.Windows.Forms.Button();
            this.buttonPr = new System.Windows.Forms.Button();
            this.buttonC = new System.Windows.Forms.Button();
            this.buttonPl = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.buttonMmin = new System.Windows.Forms.Button();
            this.buttonMr = new System.Windows.Forms.Button();
            this.buttonCos = new System.Windows.Forms.Button();
            this.buttonCtg = new System.Windows.Forms.Button();
            this.buttonTan = new System.Windows.Forms.Button();
            this.buttonMAdd = new System.Windows.Forms.Button();
            this.buttonMC = new System.Windows.Forms.Button();
            this.buttonFact = new System.Windows.Forms.Button();
            this.buttonLg = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.buttonLn = new System.Windows.Forms.Button();
            this.buttonSqrtN = new System.Windows.Forms.Button();
            this.buttonE = new System.Windows.Forms.Button();
            this.buttonSqrt3 = new System.Windows.Forms.Button();
            this.buttonPowN = new System.Windows.Forms.Button();
            this.buttonPi = new System.Windows.Forms.Button();
            this.buttonPow3 = new System.Windows.Forms.Button();
            this.buttonActg = new System.Windows.Forms.Button();
            this.buttonAtan = new System.Windows.Forms.Button();
            this.buttonSqrt = new System.Windows.Forms.Button();
            this.buttonAcos = new System.Windows.Forms.Button();
            this.buttonPow2 = new System.Windows.Forms.Button();
            this.buttonAsin = new System.Windows.Forms.Button();
            this.buttoSin = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelResult = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(91)))), ((int)(((byte)(86)))), ((int)(((byte)(67)))));
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.buttonMmin);
            this.panel1.Controls.Add(this.buttonMr);
            this.panel1.Controls.Add(this.buttonCos);
            this.panel1.Controls.Add(this.buttonCtg);
            this.panel1.Controls.Add(this.buttonTan);
            this.panel1.Controls.Add(this.buttonMAdd);
            this.panel1.Controls.Add(this.buttonMC);
            this.panel1.Controls.Add(this.buttonFact);
            this.panel1.Controls.Add(this.buttonLg);
            this.panel1.Controls.Add(this.button10);
            this.panel1.Controls.Add(this.buttonLn);
            this.panel1.Controls.Add(this.buttonSqrtN);
            this.panel1.Controls.Add(this.buttonE);
            this.panel1.Controls.Add(this.buttonSqrt3);
            this.panel1.Controls.Add(this.buttonPowN);
            this.panel1.Controls.Add(this.buttonPi);
            this.panel1.Controls.Add(this.buttonPow3);
            this.panel1.Controls.Add(this.buttonActg);
            this.panel1.Controls.Add(this.buttonAtan);
            this.panel1.Controls.Add(this.buttonSqrt);
            this.panel1.Controls.Add(this.buttonAcos);
            this.panel1.Controls.Add(this.buttonPow2);
            this.panel1.Controls.Add(this.buttonAsin);
            this.panel1.Controls.Add(this.buttoSin);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 163);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1224, 457);
            this.panel1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(91)))), ((int)(((byte)(74)))));
            this.panel3.Controls.Add(this.buttonMul);
            this.panel3.Controls.Add(this.buttonDel);
            this.panel3.Controls.Add(this.buttonRes);
            this.panel3.Controls.Add(this.buttonDiv);
            this.panel3.Controls.Add(this.buttonMinus);
            this.panel3.Controls.Add(this.buttonMin);
            this.panel3.Controls.Add(this.buttonComa);
            this.panel3.Controls.Add(this.buttonPr);
            this.panel3.Controls.Add(this.buttonC);
            this.panel3.Controls.Add(this.buttonPl);
            this.panel3.Controls.Add(this.button0);
            this.panel3.Controls.Add(this.button9);
            this.panel3.Controls.Add(this.button8);
            this.panel3.Controls.Add(this.button7);
            this.panel3.Controls.Add(this.button6);
            this.panel3.Controls.Add(this.button5);
            this.panel3.Controls.Add(this.button4);
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(450, 457);
            this.panel3.TabIndex = 1;
            // 
            // buttonMul
            // 
            this.buttonMul.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.buttonMul.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMul.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonMul.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.buttonMul.Location = new System.Drawing.Point(333, 372);
            this.buttonMul.Name = "buttonMul";
            this.buttonMul.Size = new System.Drawing.Size(65, 64);
            this.buttonMul.TabIndex = 14;
            this.buttonMul.Tag = "Operator.Multiply";
            this.buttonMul.Text = "x";
            this.buttonMul.UseVisualStyleBackColor = false;
            this.buttonMul.Click += new System.EventHandler(this.buttonPl_Click);
            // 
            // buttonDel
            // 
            this.buttonDel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.buttonDel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDel.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonDel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.buttonDel.Location = new System.Drawing.Point(135, 18);
            this.buttonDel.Name = "buttonDel";
            this.buttonDel.Size = new System.Drawing.Size(65, 64);
            this.buttonDel.TabIndex = 10;
            this.buttonDel.Text = "<-";
            this.buttonDel.UseVisualStyleBackColor = false;
            this.buttonDel.Click += new System.EventHandler(this.buttonDel_Click);
            // 
            // buttonRes
            // 
            this.buttonRes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(146)))), ((int)(((byte)(26)))));
            this.buttonRes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRes.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonRes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.buttonRes.Location = new System.Drawing.Point(333, 18);
            this.buttonRes.Name = "buttonRes";
            this.buttonRes.Size = new System.Drawing.Size(65, 64);
            this.buttonRes.TabIndex = 13;
            this.buttonRes.Text = "=";
            this.buttonRes.UseVisualStyleBackColor = false;
            this.buttonRes.Click += new System.EventHandler(this.buttonRes_Click);
            // 
            // buttonDiv
            // 
            this.buttonDiv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.buttonDiv.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDiv.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonDiv.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.buttonDiv.Location = new System.Drawing.Point(333, 287);
            this.buttonDiv.Name = "buttonDiv";
            this.buttonDiv.Size = new System.Drawing.Size(65, 64);
            this.buttonDiv.TabIndex = 12;
            this.buttonDiv.Tag = "Operator.Divide";
            this.buttonDiv.Text = "/";
            this.buttonDiv.UseVisualStyleBackColor = false;
            this.buttonDiv.Click += new System.EventHandler(this.buttonPl_Click);
            // 
            // buttonMinus
            // 
            this.buttonMinus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonMinus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMinus.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonMinus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonMinus.Location = new System.Drawing.Point(234, 18);
            this.buttonMinus.Name = "buttonMinus";
            this.buttonMinus.Size = new System.Drawing.Size(65, 64);
            this.buttonMinus.TabIndex = 10;
            this.buttonMinus.Text = "+/-";
            this.buttonMinus.UseVisualStyleBackColor = false;
            this.buttonMinus.Click += new System.EventHandler(this.buttonMinus_Click);
            // 
            // buttonMin
            // 
            this.buttonMin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.buttonMin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMin.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonMin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.buttonMin.Location = new System.Drawing.Point(333, 196);
            this.buttonMin.Name = "buttonMin";
            this.buttonMin.Size = new System.Drawing.Size(65, 64);
            this.buttonMin.TabIndex = 11;
            this.buttonMin.Tag = "Operator.Subtract";
            this.buttonMin.Text = "-";
            this.buttonMin.UseVisualStyleBackColor = false;
            this.buttonMin.Click += new System.EventHandler(this.buttonPl_Click);
            // 
            // buttonComa
            // 
            this.buttonComa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.buttonComa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonComa.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonComa.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.buttonComa.Location = new System.Drawing.Point(135, 372);
            this.buttonComa.Name = "buttonComa";
            this.buttonComa.Size = new System.Drawing.Size(65, 64);
            this.buttonComa.TabIndex = 10;
            this.buttonComa.Text = ",";
            this.buttonComa.UseVisualStyleBackColor = false;
            this.buttonComa.Click += new System.EventHandler(this.button8_Click);
            // 
            // buttonPr
            // 
            this.buttonPr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.buttonPr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPr.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonPr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.buttonPr.Location = new System.Drawing.Point(234, 372);
            this.buttonPr.Name = "buttonPr";
            this.buttonPr.Size = new System.Drawing.Size(65, 64);
            this.buttonPr.TabIndex = 10;
            this.buttonPr.Text = "%";
            this.buttonPr.UseVisualStyleBackColor = false;
            this.buttonPr.Click += new System.EventHandler(this.buttonPr_Click);
            // 
            // buttonC
            // 
            this.buttonC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.buttonC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonC.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.buttonC.Location = new System.Drawing.Point(36, 18);
            this.buttonC.Name = "buttonC";
            this.buttonC.Size = new System.Drawing.Size(65, 64);
            this.buttonC.TabIndex = 10;
            this.buttonC.Text = "C";
            this.buttonC.UseVisualStyleBackColor = false;
            this.buttonC.Click += new System.EventHandler(this.buttonC_Click);
            // 
            // buttonPl
            // 
            this.buttonPl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.buttonPl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPl.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonPl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.buttonPl.Location = new System.Drawing.Point(333, 106);
            this.buttonPl.Name = "buttonPl";
            this.buttonPl.Size = new System.Drawing.Size(65, 64);
            this.buttonPl.TabIndex = 10;
            this.buttonPl.Tag = "Operator.Add";
            this.buttonPl.Text = "+";
            this.buttonPl.UseVisualStyleBackColor = false;
            this.buttonPl.Click += new System.EventHandler(this.buttonPl_Click);
            // 
            // button0
            // 
            this.button0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.button0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button0.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button0.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.button0.Location = new System.Drawing.Point(36, 372);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(65, 64);
            this.button0.TabIndex = 9;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = false;
            this.button0.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.button9.Location = new System.Drawing.Point(234, 106);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(65, 64);
            this.button9.TabIndex = 8;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button8_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.button8.Location = new System.Drawing.Point(135, 106);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(65, 64);
            this.button8.TabIndex = 7;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.button7.Location = new System.Drawing.Point(36, 106);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(65, 64);
            this.button7.TabIndex = 6;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button8_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.button6.Location = new System.Drawing.Point(234, 196);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(65, 64);
            this.button6.TabIndex = 5;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button8_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.button5.Location = new System.Drawing.Point(135, 196);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(65, 64);
            this.button5.TabIndex = 4;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button8_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.button4.Location = new System.Drawing.Point(36, 196);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(65, 64);
            this.button4.TabIndex = 3;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button8_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.button3.Location = new System.Drawing.Point(234, 287);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(65, 64);
            this.button3.TabIndex = 2;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button8_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.button2.Location = new System.Drawing.Point(135, 287);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(65, 64);
            this.button2.TabIndex = 1;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button8_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(216)))), ((int)(((byte)(129)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(48)))), ((int)(((byte)(32)))));
            this.button1.Location = new System.Drawing.Point(36, 287);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(65, 64);
            this.button1.TabIndex = 0;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button8_Click);
            // 
            // buttonMmin
            // 
            this.buttonMmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonMmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMmin.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonMmin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonMmin.Location = new System.Drawing.Point(748, 42);
            this.buttonMmin.Name = "buttonMmin";
            this.buttonMmin.Size = new System.Drawing.Size(65, 65);
            this.buttonMmin.TabIndex = 10;
            this.buttonMmin.Text = "M-";
            this.buttonMmin.UseVisualStyleBackColor = false;
            this.buttonMmin.Click += new System.EventHandler(this.buttonMMin_Click);
            // 
            // buttonMr
            // 
            this.buttonMr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonMr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMr.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonMr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonMr.Location = new System.Drawing.Point(858, 43);
            this.buttonMr.Name = "buttonMr";
            this.buttonMr.Size = new System.Drawing.Size(65, 65);
            this.buttonMr.TabIndex = 10;
            this.buttonMr.Text = "MR";
            this.buttonMr.UseVisualStyleBackColor = false;
            this.buttonMr.Click += new System.EventHandler(this.buttonMr_Click);
            // 
            // buttonCos
            // 
            this.buttonCos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonCos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCos.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonCos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonCos.Location = new System.Drawing.Point(968, 138);
            this.buttonCos.Name = "buttonCos";
            this.buttonCos.Size = new System.Drawing.Size(65, 65);
            this.buttonCos.TabIndex = 10;
            this.buttonCos.Text = "cos";
            this.buttonCos.UseVisualStyleBackColor = false;
            this.buttonCos.Click += new System.EventHandler(this.buttonsSCT_Click);
            // 
            // buttonCtg
            // 
            this.buttonCtg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonCtg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCtg.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonCtg.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonCtg.Location = new System.Drawing.Point(968, 350);
            this.buttonCtg.Name = "buttonCtg";
            this.buttonCtg.Size = new System.Drawing.Size(65, 65);
            this.buttonCtg.TabIndex = 10;
            this.buttonCtg.Text = "ctg";
            this.buttonCtg.UseVisualStyleBackColor = false;
            this.buttonCtg.Click += new System.EventHandler(this.buttonsSCT_Click);
            // 
            // buttonTan
            // 
            this.buttonTan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonTan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTan.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonTan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonTan.Location = new System.Drawing.Point(968, 241);
            this.buttonTan.Name = "buttonTan";
            this.buttonTan.Size = new System.Drawing.Size(65, 65);
            this.buttonTan.TabIndex = 10;
            this.buttonTan.Text = "tan";
            this.buttonTan.UseVisualStyleBackColor = false;
            this.buttonTan.Click += new System.EventHandler(this.buttonsSCT_Click);
            // 
            // buttonMAdd
            // 
            this.buttonMAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonMAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMAdd.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonMAdd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonMAdd.Location = new System.Drawing.Point(639, 41);
            this.buttonMAdd.Name = "buttonMAdd";
            this.buttonMAdd.Size = new System.Drawing.Size(65, 65);
            this.buttonMAdd.TabIndex = 10;
            this.buttonMAdd.Text = "M+";
            this.buttonMAdd.UseVisualStyleBackColor = false;
            this.buttonMAdd.Click += new System.EventHandler(this.buttonMAdd_Click);
            // 
            // buttonMC
            // 
            this.buttonMC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonMC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMC.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonMC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonMC.Location = new System.Drawing.Point(526, 42);
            this.buttonMC.Name = "buttonMC";
            this.buttonMC.Size = new System.Drawing.Size(65, 65);
            this.buttonMC.TabIndex = 10;
            this.buttonMC.Text = "MC";
            this.buttonMC.UseVisualStyleBackColor = false;
            this.buttonMC.Click += new System.EventHandler(this.buttonMC_Click);
            // 
            // buttonFact
            // 
            this.buttonFact.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonFact.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFact.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonFact.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonFact.Location = new System.Drawing.Point(858, 350);
            this.buttonFact.Name = "buttonFact";
            this.buttonFact.Size = new System.Drawing.Size(65, 65);
            this.buttonFact.TabIndex = 10;
            this.buttonFact.Text = "x!";
            this.buttonFact.UseVisualStyleBackColor = false;
            this.buttonFact.Click += new System.EventHandler(this.buttonFact_Click);
            // 
            // buttonLg
            // 
            this.buttonLg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonLg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonLg.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonLg.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonLg.Location = new System.Drawing.Point(748, 350);
            this.buttonLg.Name = "buttonLg";
            this.buttonLg.Size = new System.Drawing.Size(65, 65);
            this.buttonLg.TabIndex = 10;
            this.buttonLg.Text = "lg";
            this.buttonLg.UseVisualStyleBackColor = false;
            this.buttonLg.Click += new System.EventHandler(this.buttonLog_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Verdana", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.button10.Location = new System.Drawing.Point(748, 242);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(65, 65);
            this.button10.TabIndex = 10;
            this.button10.Text = "log₂";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.buttonLog_Click);
            // 
            // buttonLn
            // 
            this.buttonLn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonLn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonLn.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonLn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonLn.Location = new System.Drawing.Point(748, 138);
            this.buttonLn.Name = "buttonLn";
            this.buttonLn.Size = new System.Drawing.Size(65, 65);
            this.buttonLn.TabIndex = 10;
            this.buttonLn.Text = "ln";
            this.buttonLn.UseVisualStyleBackColor = false;
            this.buttonLn.Click += new System.EventHandler(this.buttonLog_Click);
            // 
            // buttonSqrtN
            // 
            this.buttonSqrtN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonSqrtN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSqrtN.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonSqrtN.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonSqrtN.Location = new System.Drawing.Point(639, 350);
            this.buttonSqrtN.Name = "buttonSqrtN";
            this.buttonSqrtN.Size = new System.Drawing.Size(65, 65);
            this.buttonSqrtN.TabIndex = 10;
            this.buttonSqrtN.Text = "n√x";
            this.buttonSqrtN.UseVisualStyleBackColor = false;
            this.buttonSqrtN.Click += new System.EventHandler(this.buttonSqrt_Click);
            // 
            // buttonE
            // 
            this.buttonE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonE.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonE.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonE.Location = new System.Drawing.Point(858, 242);
            this.buttonE.Name = "buttonE";
            this.buttonE.Size = new System.Drawing.Size(65, 65);
            this.buttonE.TabIndex = 10;
            this.buttonE.Text = "e";
            this.buttonE.UseVisualStyleBackColor = false;
            this.buttonE.Click += new System.EventHandler(this.buttonE_Click);
            // 
            // buttonSqrt3
            // 
            this.buttonSqrt3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonSqrt3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSqrt3.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonSqrt3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonSqrt3.Location = new System.Drawing.Point(639, 239);
            this.buttonSqrt3.Name = "buttonSqrt3";
            this.buttonSqrt3.Size = new System.Drawing.Size(65, 65);
            this.buttonSqrt3.TabIndex = 10;
            this.buttonSqrt3.Text = "³√x";
            this.buttonSqrt3.UseVisualStyleBackColor = false;
            this.buttonSqrt3.Click += new System.EventHandler(this.buttonSqrt_Click);
            // 
            // buttonPowN
            // 
            this.buttonPowN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonPowN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPowN.Font = new System.Drawing.Font("Verdana", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonPowN.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonPowN.Location = new System.Drawing.Point(526, 350);
            this.buttonPowN.Name = "buttonPowN";
            this.buttonPowN.Size = new System.Drawing.Size(65, 65);
            this.buttonPowN.TabIndex = 10;
            this.buttonPowN.Text = "x^n";
            this.buttonPowN.UseVisualStyleBackColor = false;
            this.buttonPowN.Click += new System.EventHandler(this.buttonSquare_Click);
            // 
            // buttonPi
            // 
            this.buttonPi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonPi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPi.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonPi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonPi.Location = new System.Drawing.Point(858, 138);
            this.buttonPi.Name = "buttonPi";
            this.buttonPi.Size = new System.Drawing.Size(65, 65);
            this.buttonPi.TabIndex = 10;
            this.buttonPi.Text = "π";
            this.buttonPi.UseVisualStyleBackColor = false;
            this.buttonPi.Click += new System.EventHandler(this.buttonPi_Click);
            // 
            // buttonPow3
            // 
            this.buttonPow3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonPow3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPow3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonPow3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonPow3.Location = new System.Drawing.Point(526, 239);
            this.buttonPow3.Name = "buttonPow3";
            this.buttonPow3.Size = new System.Drawing.Size(65, 65);
            this.buttonPow3.TabIndex = 10;
            this.buttonPow3.Text = "x³";
            this.buttonPow3.UseVisualStyleBackColor = false;
            this.buttonPow3.Click += new System.EventHandler(this.buttonSquare_Click);
            // 
            // buttonActg
            // 
            this.buttonActg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonActg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonActg.Font = new System.Drawing.Font("Verdana", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonActg.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonActg.Location = new System.Drawing.Point(1077, 350);
            this.buttonActg.Name = "buttonActg";
            this.buttonActg.Size = new System.Drawing.Size(65, 65);
            this.buttonActg.TabIndex = 10;
            this.buttonActg.Text = "actg";
            this.buttonActg.UseVisualStyleBackColor = false;
            this.buttonActg.Click += new System.EventHandler(this.buttonsArc_Click);
            // 
            // buttonAtan
            // 
            this.buttonAtan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonAtan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAtan.Font = new System.Drawing.Font("Verdana", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonAtan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonAtan.Location = new System.Drawing.Point(1077, 242);
            this.buttonAtan.Name = "buttonAtan";
            this.buttonAtan.Size = new System.Drawing.Size(65, 65);
            this.buttonAtan.TabIndex = 10;
            this.buttonAtan.Text = "atan";
            this.buttonAtan.UseVisualStyleBackColor = false;
            this.buttonAtan.Click += new System.EventHandler(this.buttonsArc_Click);
            // 
            // buttonSqrt
            // 
            this.buttonSqrt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonSqrt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSqrt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonSqrt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonSqrt.Location = new System.Drawing.Point(639, 138);
            this.buttonSqrt.Name = "buttonSqrt";
            this.buttonSqrt.Size = new System.Drawing.Size(65, 65);
            this.buttonSqrt.TabIndex = 10;
            this.buttonSqrt.Text = "√x";
            this.buttonSqrt.UseVisualStyleBackColor = false;
            this.buttonSqrt.Click += new System.EventHandler(this.buttonSqrt_Click);
            // 
            // buttonAcos
            // 
            this.buttonAcos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonAcos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAcos.Font = new System.Drawing.Font("Verdana", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonAcos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonAcos.Location = new System.Drawing.Point(1077, 140);
            this.buttonAcos.Name = "buttonAcos";
            this.buttonAcos.Size = new System.Drawing.Size(65, 65);
            this.buttonAcos.TabIndex = 10;
            this.buttonAcos.Text = "acos";
            this.buttonAcos.UseVisualStyleBackColor = false;
            this.buttonAcos.Click += new System.EventHandler(this.buttonsArc_Click);
            // 
            // buttonPow2
            // 
            this.buttonPow2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonPow2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPow2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonPow2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonPow2.Location = new System.Drawing.Point(526, 138);
            this.buttonPow2.Name = "buttonPow2";
            this.buttonPow2.Size = new System.Drawing.Size(65, 65);
            this.buttonPow2.TabIndex = 10;
            this.buttonPow2.Text = "x²";
            this.buttonPow2.UseVisualStyleBackColor = false;
            this.buttonPow2.Click += new System.EventHandler(this.buttonSquare_Click);
            // 
            // buttonAsin
            // 
            this.buttonAsin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttonAsin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAsin.Font = new System.Drawing.Font("Verdana", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonAsin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttonAsin.Location = new System.Drawing.Point(1077, 42);
            this.buttonAsin.Name = "buttonAsin";
            this.buttonAsin.Size = new System.Drawing.Size(65, 65);
            this.buttonAsin.TabIndex = 10;
            this.buttonAsin.Text = "asin";
            this.buttonAsin.UseVisualStyleBackColor = false;
            this.buttonAsin.Click += new System.EventHandler(this.buttonsArc_Click);
            // 
            // buttoSin
            // 
            this.buttoSin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(210)))), ((int)(((byte)(120)))));
            this.buttoSin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttoSin.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttoSin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(65)))), ((int)(((byte)(71)))));
            this.buttoSin.Location = new System.Drawing.Point(968, 41);
            this.buttoSin.Name = "buttoSin";
            this.buttoSin.Size = new System.Drawing.Size(65, 65);
            this.buttoSin.TabIndex = 10;
            this.buttoSin.Text = "sin";
            this.buttoSin.UseVisualStyleBackColor = false;
            this.buttoSin.Click += new System.EventHandler(this.buttonsSCT_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(56)))), ((int)(((byte)(40)))));
            this.panel2.Controls.Add(this.labelResult);
            this.panel2.Location = new System.Drawing.Point(35, 38);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1126, 79);
            this.panel2.TabIndex = 1;
            // 
            // labelResult
            // 
            this.labelResult.AutoSize = true;
            this.labelResult.BackColor = System.Drawing.Color.Transparent;
            this.labelResult.Font = new System.Drawing.Font("Verdana", 20.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelResult.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(244)))), ((int)(((byte)(230)))));
            this.labelResult.Location = new System.Drawing.Point(3, 10);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(66, 65);
            this.labelResult.TabIndex = 0;
            this.labelResult.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(91)))), ((int)(((byte)(74)))));
            this.ClientSize = new System.Drawing.Size(1224, 620);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private Panel panel3;
        private Button buttonMul;
        private Button buttonRes;
        private Button buttonDiv;
        private Button buttonMin;
        private Button buttonPl;
        private Button button0;
        private Button button9;
        private Button button8;
        private Button button7;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private Panel panel2;
        private Label labelResult;
        private Button buttonPr;
        private Button buttonDel;
        private Button buttonC;
        private Button buttonComa;
        private Button buttonFact;
        private Button buttonLg;
        private Button buttonLn;
        private Button buttonSqrtN;
        private Button buttonE;
        private Button buttonSqrt3;
        private Button buttonPowN;
        private Button buttonPi;
        private Button buttonPow3;
        private Button buttonTan;
        private Button buttonSqrt;
        private Button buttonCos;
        private Button buttonPow2;
        private Button buttoSin;
        private Button buttonAtan;
        private Button buttonAcos;
        private Button buttonAsin;
        private Button buttonMr;
        private Button buttonCtg;
        private Button buttonMAdd;
        private Button buttonMC;
        private Button buttonActg;
        private Button buttonMinus;
        private Button button10;
        private Button buttonMmin;
    }
}